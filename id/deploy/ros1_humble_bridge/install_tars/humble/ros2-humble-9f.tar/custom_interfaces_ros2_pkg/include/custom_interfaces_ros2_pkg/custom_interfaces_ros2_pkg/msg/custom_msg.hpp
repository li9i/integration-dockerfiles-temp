// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CUSTOM_INTERFACES_ROS2_PKG__MSG__CUSTOM_MSG_HPP_
#define CUSTOM_INTERFACES_ROS2_PKG__MSG__CUSTOM_MSG_HPP_

#include "custom_interfaces_ros2_pkg/msg/detail/custom_msg__struct.hpp"
#include "custom_interfaces_ros2_pkg/msg/detail/custom_msg__builder.hpp"
#include "custom_interfaces_ros2_pkg/msg/detail/custom_msg__traits.hpp"

#endif  // CUSTOM_INTERFACES_ROS2_PKG__MSG__CUSTOM_MSG_HPP_
