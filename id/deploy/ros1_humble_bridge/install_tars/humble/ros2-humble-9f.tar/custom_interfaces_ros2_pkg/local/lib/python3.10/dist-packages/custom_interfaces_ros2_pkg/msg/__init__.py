from custom_interfaces_ros2_pkg.msg._custom_msg import CustomMsg  # noqa: F401
